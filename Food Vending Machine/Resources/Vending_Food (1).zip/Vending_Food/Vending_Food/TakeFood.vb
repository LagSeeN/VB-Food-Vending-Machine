﻿Public Class TakeFood
    Private Sub BtnBuy_Click(sender As Object, e As EventArgs)
        'กลับไปหน้า home
    End Sub

    Private Sub BtnNotBuy_Click(sender As Object, e As EventArgs)
        Me.Close()
    End Sub
End Class